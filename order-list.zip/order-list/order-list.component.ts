import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CustomButtonRendererComponent } from '../custom-button-renderer/custom-button-renderer.component';
import { CustomCheckboxRendererComponent } from '../custom-checkbox-renderer/custom-checkbox-renderer.component';
import { CustomLinkRendererComponent } from '../custom-link-renderer/custom-link-renderer.component';
import { ColDef, GridApi, GridOptions } from 'ag-grid-community';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.scss',
})
export class OrderListComponent implements OnInit {
  columnDefs = [
    { field: 'orderId', headerName: 'Order ID' },
    { field: 'productName', headerName: 'Product Name' },
    { field: 'quantity', headerName: 'Quantity' },
    { field: 'price', headerName: 'Price ($)' },
  ];

  rowData: any[] = [];
  gridOptions: GridOptions = {
    onColumnMoved: () => this.saveColumnState(),
  };

  private gridApi!: GridApi;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get<any[]>('/assets/jsonFiles/orders-list.json').subscribe((data) => {
      this.rowData = data;
    });
  }

  onGridReady(params: { api: GridApi }): void {
    this.gridApi = params.api;
    this.loadColumnState();
  }

  saveColumnState(): void {
    const columnState = this.gridApi.getColumnState();
    if (columnState) {
      localStorage.setItem('columnState', JSON.stringify(columnState));
    }
  }

  loadColumnState(): void {
    const savedState = localStorage.getItem('columnState');
    if (savedState) {
      const columnState = JSON.parse(savedState);
      this.gridApi.applyColumnState({ state: columnState, applyOrder: true });
    }
  }

  resetColumnState(): void {
    this.gridApi.applyColumnState({
      state: this.columnDefs.map((col) => ({ colId: col.field, width: 150 })),
      applyOrder: true,
    });
    localStorage.removeItem('columnState');
  }
}
