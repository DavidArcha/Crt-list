import { DatePipe } from '@angular/common';
import { Component, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

interface DataValue {
  columnName: string;
  original: string;
  new: string;
  action: string;
}

interface HistoryEntry {
  user: string;
  time: string;
  dataValues: DataValue[];
}

@Component({
  selector: 'app-history-actions',
  templateUrl: './history-actions.component.html',
  styleUrls: ['./history-actions.component.scss'],
  providers: [DatePipe],
})
export class HistoryActionsComponent {
  @Input() historyData: HistoryEntry[] = [];

  constructor(
    private translateService: TranslateService,
    private datePipe: DatePipe
  ) {}

  formatTime(timeString: string): string {
    return this.datePipe.transform(timeString, 'dd MMM, yyyy, h:mm a') || '';
  }

  translateColumnName(columnName: string): string {
    // Prefix 'inventory' to access the appropriate key in translation files
    return this.translateService.instant(`inventory.${columnName}`);
  }
}
